﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Framework.Controls
{
    /// <summary>
    /// Defines a custom dialog container
    /// </summary>
    public sealed class CustomDialogContainer : ContentControl
    {
        /// <summary>
        /// Initialize a new instance
        /// </summary>
        public CustomDialogContainer()
        {
            DefaultStyleKey = typeof(CustomDialogContainer);
        }
    }
}
