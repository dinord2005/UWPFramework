﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Connectivity;

namespace Framework.Services.Network
{
    /// <summary>
    /// Network connectivity service implementation used to handle network services
    /// </summary>
    public class NetworkService : INetworkService
    {
        #region Fields
        //Services

        #endregion

        #region Ctors

        /// <summary>
        /// Initialize a new instance
        /// </summary>
        public NetworkService()
        {
       
            NetworkInformation.NetworkStatusChanged += OnNetworkStatusChanged;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets indication wether device hase Local and Internet access.
        /// </summary>
        public Boolean HasConnectivity
        {
            get
            {
                ConnectionProfile profile = NetworkInformation.GetInternetConnectionProfile();
                return profile.GetNetworkConnectivityLevel() == NetworkConnectivityLevel.InternetAccess;
            }
        }

        /// <summary>
        /// Gets indication wether device is connected in WIFI or ETHERNET.
        /// </summary>
        public Boolean IsConnectedWifiEthernet
        {
            get
            {
                Boolean _isConnectedWifiEthernet = false;

                ConnectionProfile profile = NetworkInformation.GetInternetConnectionProfile();
                if (profile != null)
                {
                    uint interfaceType = profile.NetworkAdapter.IanaInterfaceType;

                    //Le 71 c'est pour la Wifi et 6 pour l'Ethernet
                    if (interfaceType == 71 || interfaceType == 6)
                    {
                        _isConnectedWifiEthernet = true;
                    }

                }
                return _isConnectedWifiEthernet;
            }
        }

        #endregion

        #region Methodes

        #endregion

        #region Handlers
        /// <summary>
        /// Called when network status changed
        /// </summary>
        /// <param name="sender">The event sender</param>
        void OnNetworkStatusChanged(Object sender)
        {
            //Log.Info("NetworkConnectivity changed to {0}", NetworkInformation.GetInternetConnectionProfile().GetNetworkConnectivityLevel());
        }
        #endregion
    }
}
