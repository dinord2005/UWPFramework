﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Services.Network
{
    /// <summary>
    /// Interface definition of a network  service
    /// </summary>
    public interface INetworkService
    {
        /// <summary>
        /// Gets indication wether device hase Local and Internet access.
        /// </summary>
        Boolean HasConnectivity
        {
            get;
        }

        /// <summary>
        /// Gets indication wether device is connected in Wifi / Ethernet.
        /// </summary>
        Boolean IsConnectedWifiEthernet
        {
            get;
        }


    }
}
