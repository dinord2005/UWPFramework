﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Services.Dialogs
{
    /// <summary>
    /// Dialog result enumeration
    /// </summary>
    public enum DialogResult
    {
        /// <summary>
        /// Cancel
        /// </summary>
        Cancel = 2,
        /// <summary>
        /// No
        /// </summary>
        No = 7,
        /// <summary>
        /// None
        /// </summary>
        None = 0,
        /// <summary>
        /// Ok
        /// </summary>
        Ok = 1,
        /// <summary>
        /// Yes
        /// </summary>
        Yes = 6
    }
}
