﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Services.Dialogs
{
    /// <summary>
    /// Dialog button enumeration
    /// </summary>
    public enum DialogButton
    {
        /// <summary>
        /// Displays only the OK button.
        /// </summary>
        Ok = 1,

        /// <summary>
        /// Displays only the Cancel button.
        /// </summary>
        Cancel = 2,

        /// <summary>
        /// Displays both the OK and Cancel buttons.
        /// </summary>
        OkCancel = Ok | Cancel,

        /// <summary>
        /// Displays only the OK button.
        /// </summary>
        Yes = 4,

        /// <summary>
        /// Displays only the Cancel button.
        /// </summary>
        No = 8,

        /// <summary>
        /// Displays both the OK and Cancel buttons.
        /// </summary>
        YesNo = Yes | No,
    }
}
