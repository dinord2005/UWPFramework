﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Services.Dialogs
{
    /// <summary>
    /// Class defining a dialog command
    /// </summary>
    public class DialogCommand
    {
        /// <summary>
        /// Gets or sets the dialog command identifier
        /// </summary>
        public object Id
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the dialog command label
        /// </summary>
        public string Label
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the action to perform
        /// </summary>
        public Action Invoked
        {
            get;
            set;
        }
    }
}
