﻿using Framework.Controls;
using GalaSoft.MvvmLight.Ioc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;

namespace Framework.Services.Dialogs
{
    /// <summary>
    ///     Dialog service implementation
    /// </summary>
    public class DialogService : IDialogService
    {
        #region Fields

        //Data
        private readonly IDictionary<String, Type> _viewRegistered;
        private MessageDialog _activeMessageDialog;
        private Popup _activePopup;
        private SettingsFlyout _activeSettingsFlyout;

        //Services
       

        #endregion

        #region Ctors

        /// <summary>
        ///     Initialize a new instance
        /// </summary>
        [PreferredConstructor]
        public DialogService()
        {
           
            _viewRegistered = new Dictionary<String, Type>();
        }

        #endregion

        #region Methods


        /// <summary>
        ///     Displays a message box to the user
        /// </summary>
        /// <param name="buttons">Buttons to display</param>
        /// <param name="caption">The message box caption (title)</param>
        /// <param name="content">The message box content</param>
        public async Task<DialogResult> ShowMessageBoxAsync(DialogButton buttons,
                                                            String content,
                                                            String caption)
        {
            var dialogTask = new TaskCompletionSource<DialogResult>();

            MessageDialog md = new MessageDialog(content,
                                                 caption)
            { DefaultCommandIndex = 0 };

            if (buttons.HasFlag(DialogButton.Ok))
            {
                md.Commands.Add(new UICommand("Ok",
                                              cmd => dialogTask.SetResult(DialogResult.Ok)));
            }

            if (buttons.HasFlag(DialogButton.Yes))
            {
                md.Commands.Add(new UICommand("Oui",
                                              cmd => dialogTask.SetResult(DialogResult.Yes)));
            }

            if (buttons.HasFlag(DialogButton.No))
            {
                md.Commands.Add(new UICommand("Non",
                                              cmd => dialogTask.SetResult(DialogResult.No)));
            }

            if (buttons.HasFlag(DialogButton.Cancel))
            {
                md.Commands.Add(new UICommand("Annuler",
                                              cmd => dialogTask.SetResult(DialogResult.Cancel)));
                md.CancelCommandIndex = (uint)md.Commands.Count - 1;
            }

            if (buttons.HasFlag(DialogButton.YesNo) || buttons.HasFlag(DialogButton.OkCancel))
            {
                md.CancelCommandIndex = 1;
            }
            else
            {
                md.CancelCommandIndex = 0;
            }


            await md.ShowAsync();

            return await dialogTask.Task;
        }


        /// <summary>
        /// Shows a dialog message
        /// </summary>
        /// <param name="message">The message to display</param>
        /// <param name="title">The dialog title</param>
        /// <param name="dialogCommands">The dialog commands to display</param>
        /// <returns>The asynchronous action</returns>
        public async Task ShowMessageBoxAsync(String message,
                                              String title,
                                              IEnumerable<DialogCommand> dialogCommands)
        {
            // Only show one dialog at a time.
            if (_activeMessageDialog == null)
            {
                _activeMessageDialog = new MessageDialog(message,
                                                         title);

                if (dialogCommands != null)
                {
                    IEnumerable<UICommand> commands = dialogCommands.Select(c => new UICommand(c.Label,
                                                                                               command =>
                                                                                               {
                                                                                                   if (c.Invoked != null)
                                                                                                       c.Invoked();
                                                                                               },
                                                                                               c.Id));

                    foreach (UICommand command in commands)
                    {
                        _activeMessageDialog.Commands.Add(command);
                    }
                }

                await _activeMessageDialog.ShowAsync();
                _activeMessageDialog = null;
            }
        }

        /// <summary>
        /// Registers a view associed to a specific name
        /// </summary>
        /// <param name="viewName">The view name</param>
        /// <param name="viewType">The view type</param>
        public void RegisterView(String viewName,
                                 Type viewType)
        {
            if (_viewRegistered.ContainsKey(viewName))
                return;

            _viewRegistered.Add(viewName,
                                viewType);


        }

        /// <summary>
        /// Displays a settings flyout
        /// </summary>
        /// <param name="settingsFlyoutName">The flyout settings name</param>
        /// <param name="viewModel">The flyout view model</param>
        /// <returns>The asynchronous task</returns>
        public Task ShowSettingsFlyoutAsync(String settingsFlyoutName,
                                            Object viewModel = null)
        {
            // Only show one dialog at a time.
            if ((_activeSettingsFlyout == null) && (_viewRegistered.ContainsKey(settingsFlyoutName)))
            {
                _activeSettingsFlyout = SimpleIoc.Default.GetInstance(_viewRegistered[settingsFlyoutName]) as SettingsFlyout;

                if (_activeSettingsFlyout != null)
                {
                    if (viewModel != null)
                        _activeSettingsFlyout.DataContext = viewModel;

                    TaskCompletionSource<Boolean> tcs = new TaskCompletionSource<Boolean>();

                    RoutedEventHandler onUnloaded = null;

                    onUnloaded = (sender,
                                  args) =>
                    {
                        _activeSettingsFlyout.Unloaded -= onUnloaded;
                        _activeSettingsFlyout = null;
                        tcs.SetResult(true);
                    };

                    _activeSettingsFlyout.Unloaded += onUnloaded;
                    _activeSettingsFlyout.ShowIndependent();

                    return tcs.Task;
                }
            }

            return Task.Delay(0);
        }

        /// <summary>
        /// Displays a popup of a specific name
        /// </summary>
        /// <param name="popupName">The popup name</param>
        /// <param name="viewModel">The popup view model</param>
        /// <returns>The asynchronous task</returns>
        public Task ShowAsync(String popupName,
                              Object viewModel = null)
        {
            // Only show one dialog at a time.
            if ((_activePopup != null) || (!_viewRegistered.ContainsKey(popupName)))
                return Task.Delay(0);

            TaskCompletionSource<Boolean> tcs = new TaskCompletionSource<Boolean>();

            _activePopup = new Popup();

            CustomDialogContainer container = new CustomDialogContainer
            {
                Content = Activator.CreateInstance(_viewRegistered[popupName]) as FrameworkElement,
                Width = Window.Current.Bounds.Width,
                Height = Window.Current.Bounds.Height
            };

            _activePopup.IsLightDismissEnabled = true;

            _activePopup.Child = container;

            if (viewModel != null)
                _activePopup.DataContext = viewModel;

            EventHandler<Object> onClosed = null;

            onClosed = (sender,
                        args) =>
            {
                _activePopup.Closed -= onClosed;
                _activePopup = null;
                tcs.SetResult(true);
            };

            _activePopup.Closed += onClosed;

            _activePopup.IsOpen = true;

            return tcs.Task;
        }

        /// <summary>
        /// Closes the active dialog
        /// </summary>
        public void CloseActiveDialog()
        {
            if (_activePopup != null)
            {
                _activePopup.IsOpen = false;
            }
        }
        #endregion
    }
}
