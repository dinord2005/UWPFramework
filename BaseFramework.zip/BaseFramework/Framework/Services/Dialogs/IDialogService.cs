﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Services.Dialogs
{
    /// <summary>
    /// Interface definitions for dialog service
    /// </summary>
    public interface IDialogService
    {
        /// <summary>
        /// Displays a popup of a specific name
        /// </summary>
        /// <param name="popupName">The popup name</param>
        /// <param name="viewModel">The popup view model</param>
        /// <returns>The asynchronous task</returns>
        Task ShowAsync(String popupName,
                       Object viewModel = null);

        /// <summary>
        /// Displays a massage box to the user
        /// </summary>
        /// <param name="buttons">Buttons to display</param>
        /// <param name="caption">The message box caption (title)</param>
        /// <param name="content">The message box content</param>
        Task<DialogResult> ShowMessageBoxAsync(DialogButton buttons,
                                               String content,
                                               String caption);

        /// <summary>
        /// Shows a dialog message
        /// </summary>
        /// <param name="message">The message to display</param>
        /// <param name="title">The dialog title</param>
        /// <param name="dialogCommands">The dialog commands to display</param>
        /// <returns>The asynchronous action</returns>
        Task ShowMessageBoxAsync(String message,
                                 String title,
                                 IEnumerable<DialogCommand> dialogCommands);

        /// <summary>
        /// Displays a settings flyout
        /// </summary>
        /// <param name="settingsFlyoutName">The flyout settings name</param>
        /// <param name="viewModel">The flyout view model</param>
        /// <returns>The asynchronous task</returns>
        Task ShowSettingsFlyoutAsync(String settingsFlyoutName,
                                     Object viewModel = null);

        /// <summary>
        /// Registers a view associed to a specific name
        /// </summary>
        /// <param name="viewName">The view name</param>
        /// <param name="viewType">The view type</param>
        void RegisterView(String viewName,
                          Type viewType);

        /// <summary>
        /// Closes the active dialog
        /// </summary>
        void CloseActiveDialog();
    }
}
