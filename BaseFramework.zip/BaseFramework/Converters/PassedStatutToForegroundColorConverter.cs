﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Data;

namespace Converters
{
  public  class PassedStatutToForegroundColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            int IsPassed = 0;
            String BgColor = String.Empty;

            //check if value is null

            if (value != null)
            {
                IsPassed = (int)value;
            }

            if (IsPassed == 0)
            {
                BgColor = "#3B5998";
            }
            else
            {
                BgColor = "Yellow";
            }

            return BgColor;

        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
