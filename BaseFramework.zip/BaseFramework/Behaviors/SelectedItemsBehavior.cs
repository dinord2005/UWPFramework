﻿using Behaviors.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Behaviors
{
    /// <summary>
    /// Allows ListViewBase to handle selected items with bindings in an MVVM project
    /// </summary>
    public class SelectedItemsBehavior : Behavior<ListViewBase>
    {
        private Boolean _isHandlingSelection;

        /// <summary>
        /// DP definition of SelectedItems property
        /// </summary>
        public static readonly DependencyProperty SelectedItemsProperty = DependencyProperty.Register("SelectedItems",
                                                                                                      typeof(IList),
                                                                                                      typeof(SelectedItemsBehavior),
                                                                                                      new PropertyMetadata(new ObservableCollection<object>(),
                                                                                                                           OnSelectedItemsChanged));


        /// <summary>
        /// Initialize a new instance
        /// </summary>
        public SelectedItemsBehavior()
        {
        }

        /// <summary>
        /// Gets or sets the selected items
        /// </summary>
        public IList SelectedItems
        {
            get
            {
                return (IList)GetValue(SelectedItemsProperty);
            }
            set
            {
                SetValue(SelectedItemsProperty,
                         value);
            }
        }

        /// <summary>
        /// Called when behavior is attached
        /// </summary>
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.SelectionChanged += OnSelectionChanged;
        }

        /// <summary>
        /// Called when behavior is detaching
        /// </summary>
        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.SelectionChanged -= OnSelectionChanged;
        }

        /// <summary>
        /// Called when selected items property changes
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="args">The event args</param>
        private static void OnSelectedItemsChanged(DependencyObject sender,
                                                   DependencyPropertyChangedEventArgs args)
        {
            if (args.OldValue is INotifyCollectionChanged)
            {
                (args.OldValue as INotifyCollectionChanged).CollectionChanged -= HandleSelectionChanged;
            }

            if (args.NewValue is INotifyCollectionChanged)
            {
                (args.NewValue as INotifyCollectionChanged).CollectionChanged += HandleSelectionChanged;
            }
        }

        private static void HandleSelectionChanged(Object sender,
                                                   NotifyCollectionChangedEventArgs e)
        {
            SelectedItemsBehavior behavior = sender as SelectedItemsBehavior;

            if (behavior == null)
                return;

            if (behavior.AssociatedObject == null)
                return;

            IList<Object> selectedItems = behavior.AssociatedObject.SelectedItems;

            if (e.OldItems != null)
            {
                foreach (Object item in e.OldItems)
                {
                    if (selectedItems.Contains(item))
                    {
                        selectedItems.Remove(item);
                    }
                }
            }

            if (e.NewItems != null)
            {
                foreach (Object item in e.NewItems)
                {
                    if (!selectedItems.Contains(item))
                    {
                        selectedItems.Add(item);
                    }
                }
            }
        }

        private void OnSelectionChanged(object sender,
                                        SelectionChangedEventArgs e)
        {
            if (_isHandlingSelection)
                return;

            _isHandlingSelection = true;

            foreach (object item in e.RemovedItems)
            {
                if (SelectedItems.Contains(item))
                {
                    SelectedItems.Remove(item);
                }
            }

            foreach (var item in e.AddedItems)
            {
                if (!SelectedItems.Contains(item))
                {
                    SelectedItems.Add(item);
                }
            }

            _isHandlingSelection = false;
        }
    }
}
