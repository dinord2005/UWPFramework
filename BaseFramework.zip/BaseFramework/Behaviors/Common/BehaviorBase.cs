﻿using Microsoft.Xaml.Interactivity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace Behaviors.Common
{
    /// <summary>
    /// A base class for behaviors, can be used in native environments too
    /// </summary>
    public abstract class BehaviorBase : DependencyObject, IBehavior
    {
        /// <summary>
        /// Gets or sets the Windows.UI.Xaml.DependencyObject to which the Microsoft.Xaml.Interactivity.IBehavior is attached.
        /// </summary>
        public DependencyObject AssociatedObject { get; set; }

        /// <summary>
        /// Attaches to the specified object.
        /// </summary>
        /// <param name="associatedObject">The <see cref="DependencyObject"/> to which the Microsoft.Xaml.Interactivity.IBehavior will be attached.</param>
        public virtual void Attach(DependencyObject associatedObject)
        {
            AssociatedObject = associatedObject;
        }

        /// <summary>
        /// Detaches this instance from its associated object.
        /// </summary>
        public virtual void Detach()
        {
        }
    }
}
