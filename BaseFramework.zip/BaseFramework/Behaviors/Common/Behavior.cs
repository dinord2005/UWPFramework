﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace Behaviors.Common
{
    /// <summary>
    /// A generic base class behavior
    /// </summary>
    /// <typeparam name="T">The attached <see cref="DependencyObject"/> type</typeparam>
    public abstract class Behavior<T> : BehaviorBase where T : DependencyObject
    {
        /// <summary>
        /// Gets or sets the Windows.UI.Xaml.DependencyObject to which the Microsoft.Xaml.Interactivity.IBehavior is attached.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public new T AssociatedObject { get; set; }

        /// <summary>
        /// Attaches to the specified object.
        /// </summary>
        /// <param name="associatedObject">The <see cref="DependencyObject"/> to which the Microsoft.Xaml.Interactivity.IBehavior will be attached.</param>
        public override void Attach(DependencyObject associatedObject)
        {
            base.Attach(associatedObject);
            this.AssociatedObject = (T)associatedObject;
            OnAttached();
        }

        /// <summary>
        /// Detaches this instance from its associated object.
        /// </summary>
        public override void Detach()
        {
            base.Detach();
            OnDetaching();
        }

        /// <summary>
        /// Called when behavior is attached
        /// </summary>
        protected virtual void OnAttached()
        {
        }

        /// <summary>
        /// Called when behavior is detached
        /// </summary>
        protected virtual void OnDetaching()
        {
        }

    }
}
